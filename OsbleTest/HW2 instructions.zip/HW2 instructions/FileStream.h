#ifndef FILESTREAMH
#define FILESTREAMH

#include "Stream.h"
#include <string>
#include <iostream>
#include <fstream>

class FileStream : public Stream
{
public:
	enum FileMode
	{
		OpenExistingR = 1,
        OpenExistingRW = 2,
		CreateW = 3,
		CreateRW = 4
    };
        
    // You must implement this constructor:
    FileStream(const std::string& fileName, FileMode mode);
}
#endif